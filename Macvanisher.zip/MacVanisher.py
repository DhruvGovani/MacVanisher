#-----------------------------Module import------------------------------------------#

import re
import subprocess
from random import choice,randint
import os

# ------------------------------IGNORE THIS CODE--------------------------------------#

def intro():
    # intro

    os.system("clear")

    patterRand = randint(0, 2)

    if patterRand == 0:

            print("\n#################################################")
            print("#################################################")
            print("############### MacVanisher #####################")
            print("############# BY DHRUV GOVANI ###################")
            print("#################################################")
            print("#################################################\n")

    elif patterRand == 1:
            print("\n███████▓█████▓▓╬╬╬╬╬╬╬╬▓███▓╬╬╬╬╬╬╬▓╬╬▓█")
            print("████▓▓▓▓╬╬▓█████╬╬╬╬╬╬███▓╬╬╬╬╬╬╬╬╬╬╬╬╬█")
            print("███▓▓▓▓╬╬╬╬╬╬▓██╬╬╬╬╬╬▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("████▓▓▓╬╬╬╬╬╬╬▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("███▓█▓██Mac██▓███▓╬╬╬╬╬╬██Vanisher█▓╬╬▓█")
            print("████████████████▓█▓╬╬╬╬╬▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬█")
            print("███▓▓▓▓▓▓▓╬╬▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("████▓▓▓╬╬╬╬▓▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("███▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("█████▓▓▓▓▓▓▓▓█▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█")
            print("█████▓▓B▓Y▓▓██▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██")
            print("█████▓▓▓▓▓████▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██")
            print("████▓█▓▓▓▓██▓▓▓▓██╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██")
            print("████▓▓███▓▓▓▓▓▓▓██▓╬╬╬╬╬╬╬╬╬╬╬╬█▓╬▓╬╬▓██")
            print("█████▓███▓▓▓▓▓▓▓▓DHRUV▓GOVANI╬█▓╬╬╬╬╬▓██")
            print("█████▓▓█▓███▓▓▓████╬▓█▓▓╬╬╬▓▓█▓╬╬╬╬╬╬███")
            print("██████▓██▓███████▓╬╬╬▓▓╬▓▓██▓╬╬╬╬╬╬╬▓███")
            print("███████▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬████")
            print("███████▓▓██▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓████")
            print("████████▓▓▓█████▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█████")
            print("█████████▓▓▓█▓▓▓▓▓███▓╬╬╬╬╬╬╬╬╬╬╬▓██████")
            print("██████████▓▓▓█▓▓▓╬▓██╬╬╬╬╬╬╬╬╬╬╬▓███████")
            print("███████████▓▓█▓▓▓▓███▓╬╬╬╬╬╬╬╬╬▓████████")
            print("██████████████▓▓▓████╬╬╬╬╬╬╬╬╬██████████")
            print("███████████████▓▓▓██▓▓╬╬╬╬╬╬▓███████████\n")

    else:
            print("\n         ──────▄▀▄─────▄▀▄")
            print("         ─────▄█░░▀▀▀▀▀░░█▄")
            print("         ─▄▄──█░░░░░░░░░░░█──▄▄")
            print("         █▄▄█─█░░▀░░┬░░▀░░█─█▄▄█")
            print("▂▃▄▅▆▇█▓▒░░M░A░C░V░A░N░I░S░H░E░R░░▒▓█▇▆▅▄▃▂")
            print("▂▃▄▅▆▇█▓▒░░░♥ BY DHRUV GOVANI ♥░░░░▒▓█▇▆▅▄▃▂")
            print("●▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬๑۩۩๑▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬●\n")


intro()
print("\nRULES:\n \n1. MUST CHECK FOR FILES FOR SAME DIRECTORY AS MacVanisher\n2. Must Use 'Clean' of choice number 7 before using new Interface \n")


#------------------------------------ ATTENTION -------------------------------------------#

#----------------------------- Functions starts from here----------------------------------#

def currentmac(interface):
    # shell command
    output = subprocess.check_output(["ifconfig " + str(interface) + " "], shell=True)
    # re to search mac address
    curent_mac = re.search(r"\w\w:\w\w:\w\w:\w\w:\w\w:\w\w", str(output))
    return curent_mac.group()


def changemac(interface, new_mac):

     subprocess.call(["ifconfig " + str(interface) + " down"], shell=True)
     subprocess.call(["ifconfig " + str(interface) + " hw ether " + str(new_mac)], shell=True)
     subprocess.call(["ifconfig " + str(interface) + " up"], shell=True)


def savePermanantMac(macAddress):
    readFile = open("permanantMac.txt","r+")
    macFlag = readFile.read()

    if macFlag == "":
     fp = open("permanantMac.txt", "w+")
     fp.write(macAddress)
    else:
     print("")


def rollBacktoPermanant(interface):
    fp = open("permanantMac.txt", "r+")
    permanant_mac_from_file = fp.read()

    subprocess.call(["ifconfig " + str(interface) + " down"], shell=True)
    subprocess.call(["ifconfig " + str(interface) + " hw ether " + str(permanant_mac_from_file)], shell=True)
    subprocess.call(["ifconfig " + str(interface) + " up"], shell=True)

    if permanant_mac_from_file == currentmac(interface):
        print("\nRolled Back to Permanant Mac Address")
    else:
        print("\nSomething Went Wrong !")


def getPermanantMac():
    fp = open("permanantMac.txt", "r+")
    permanant_mac_address = fp.read()
    return permanant_mac_address

def printStats(interface):
    print("\nCurrent Mac Address: {}".format(currentmac(interface)))
    print("Permanant Mac : {}".format(getPermanantMac()))
    print("Last Used Interface : {}\n".format(getLastUsedInterface()))

def writeMacHistory(newmacaddress,oldmacaddress):

    if newmacaddress == old_mac_address:
        print("")
    else:
     fp = open("macHistory.txt","a+")
     fp.write("\n" + newmacaddress)

def readMacHistory():

    mac_history = []
    for word in  open("macHistory.txt").read().split():
        mac_history.append(word)

    for i in range(len(mac_history)):
        print(mac_history[i])

def random_Mac():
    cisco = ["00","40","96"]
    dell = ["00","14","22"]
    xerox = ["00","00","00"]
    lectron = ["00","02","96"]
    openNetwork = ["00","02","2a"]
    Logic = ["00","02","3b"]
    solid = ["00","02","4b"]
    tokyo = ["00","02","4e"]
    ipAccess = ["00","02","6e"]
    ccor = ["00","02","77"]
    broadframe = ["00","02","7d"]
    apex = ["00","02","99"]
    bit = ["00","06","E7"]

    mac_address = choice([cisco,dell,xerox,lectron,openNetwork,Logic,solid,tokyo,ipAccess,ccor,broadframe,apex,bit])

    for i in range(3):
        onebit = choice(str(randint(0,9)))
        secondbit = choice(str(randint(0,9)))
        thirdbit = (str(onebit + secondbit))
        mac_address.append(thirdbit)

    return ":".join(mac_address)

def getLastThreeBit():
    mac_address = []

    for i in range(3):
        onebit = choice(str(randint(0, 9)))
        secondbit = choice(str(randint(0, 9)))
        thirdbit = (str(onebit + secondbit))
        mac_address.append(thirdbit)

    return ":".join(mac_address)

def changeMacForMacOS(interface,newMacAddress):

    subprocess.call(["sudo ifconfig " + str(interface) + " ether " + str(newMacAddress)], shell=True)

def rollbackMacforMacOS(interface):
    fp = open("permanantMac.txt", "r+")
    permanant_mac_from_file = fp.read()

    subprocess.call(["sudo ifconfig " + str(interface) + " ether " + str(permanant_mac_from_file)], shell= True)
def WritelastUsedInterface(interface):
    fpWrite = open("interface.txt", "w+")
    fpRead = open("interface.txt","r+")
    currentInterface = fpRead.read()

    if currentInterface == "":
        fpWrite.write(interface)
    else:
        print("")

def getLastUsedInterface():

    fp = open("interface.txt","r+")
    return fp.read()
# taking interface from user


def clean():

    macHistory = open("macHistory.txt","w+")
    macHistory.write("")
    permMac = open("permanantMac.txt","w+")
    permMac.write("")
    intF = open("interface.txt","w+")
    intF.write("")
def hardRestoreMac(interface):

    hardAddressCheck = subprocess.check_output(["ethtool -P "+str(interface)], shell=True)
    hardAddress = re.search(r"\w\w:\w\w:\w\w:\w\w:\w\w:\w\w",str(hardAddressCheck))
    clean()
    return  hardAddress.group()


#--------------------------------MAIN FUNCTION--------------------------------------#

interface = input("\nEnter Interface Name: ").strip()
#printing mac addresses
#saving permanant mac address
current_mac_address = currentmac(interface)
savePermanantMac(current_mac_address)
WritelastUsedInterface(interface)
old_mac_address = current_mac_address
printStats(interface)
#taking user choice for mac address function

#------------------------------------Option Menu------------------------------------#

userChoice = input("\nSelect Your choice \n1.Set The Mac Address\n2.Rollback to Permanant Mac Address\n3.Change Mac to a Random mac Address\n4.Read Mac history\n5.MacOs\n6.Rollback to permanant Mac Address [MacOSX]\n7.Don't Change Vendor Just change last 3 Bits\n8.Clean\n9.Hard Restore My Mac\nAnswer(anything to VIEW HELP): ")

if userChoice == "1":

 #changing mac to user defined mac
 print("\nFORMAT : XX:XX:XX:XX:XX:XX")
 user_defined_mac = input("\nenter new mac address: ").strip()
 changemac(interface,user_defined_mac)
 writeMacHistory(user_defined_mac,old_mac_address)
 #printing stats after changes
 intro()
 printStats(interface)

elif userChoice == "2":

    rollBacktoPermanant(interface)
    intro()
    printStats(interface)

elif userChoice == "3":
    random_mac_address = random_Mac()
    changemac(interface,random_mac_address)
    writeMacHistory(random_mac_address, old_mac_address)
    intro()
    printStats(interface)

elif userChoice == "4":
    intro()
    print("History:\n")
    readMacHistory()

elif userChoice == "5":

        mac_vendor = getPermanantMac()
        lastbit = getLastThreeBit()
        newMac = mac_vendor[:9] + lastbit
        changeMacForMacOS(interface, newMac)
        intro()
        printStats(interface)
        print("\nIf your Mac is Not Changed:\nTurn on And off Wifi if you lost the internet connection \nDisconnect active wifi connections and try again.")
elif userChoice == "6":

    rollbackMacforMacOS(interface)
    print("\nIf your Mac is Not Changed:\nTurn on And off Wifi if you lost the internet connection \nDisconnect active wifi connections and try again.")


elif userChoice == "7":

    lastbit = getLastThreeBit()
    newMacSameVendor = current_mac_address[:9] + lastbit
    changemac(interface,newMacSameVendor)
    intro()
    printStats(interface)

elif userChoice == "8":

    clean()
    print("\nAll Files Cleaned Up, Now you can use new interface easily!")

elif userChoice == "9":

    hardAddress = hardRestoreMac(interface)
    savePermanantMac(hardAddress)
    changemac(interface,hardAddress)
    print("Hard restore Done")
    intro()
    printStats(interface)

else:
    intro()
    print("\n #------------Help----------#\n")
    print("1.Set The Mac Address : Set the Current Mac Address to Mac Address entered by You")
    print("2.Rollback to Permanent Mac Address : Rollback to permanent mac address stored in the file when you first executed the MacVanisher")
    print("3.Change Mac to a Random mac Address : Change your current mac address to a random mac address")
    print("4.Read Mac history : Prints the history of mac addresses used by you ever")
    print("5.MacOs : Select this option if you are executing the script on MacOS")
    print("6.Don't Change Vendor Just change last 3 Bits : this will change only last three bit of your mac address")
    print("7.Clean : use this function to clean all the files and history")
    print("8.Hard Restore My Mac : to restore your permanent mac in case of misclicks if you loose your permanent mac file")



print("\nThank You For Using MacVanisher \n \t\t\t - Dhruv Govani")